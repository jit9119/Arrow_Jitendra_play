#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
open "$DIR/Play-Arrow-Puzzle.html" 2>/dev/null || xdg-open "$DIR/Play-Arrow-Puzzle.html" 2>/dev/null
