@echo off
title Arrow Puzzle - Full Offline Edition
start "" "%~dp0Play-Arrow-Puzzle.html"
